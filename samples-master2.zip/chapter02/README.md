## Chapter 2: Hello World microservices security
* Your first microservice
* Setting up an OAuth 2.0 server 
* Securing a microservice with OAuth 2.0 
* Invoking a secured microservice with a client application 
* Authorization of requests based on OAuth 2.0 scopes
* Summary  
