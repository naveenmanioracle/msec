docker run  -p 8181:8181 openpolicyagent/opa:0.15.0 run  --server  --log-level debug
