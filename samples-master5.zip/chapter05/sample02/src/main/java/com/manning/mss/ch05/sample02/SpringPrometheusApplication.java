package com.manning.mss.ch05.sample02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringPrometheusApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringPrometheusApplication.class, args);
    }
}
