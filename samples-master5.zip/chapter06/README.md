
## Chapter 6: Securing service-to-service communication with certificates
* Why use mTLS? 
* Creating certificates
* Securing microservices with TLS 
* Engaging mTLS
* Challenges in key management 
* Key rotation
* Monitoring key use 
* SPIFFE 
* Summary
